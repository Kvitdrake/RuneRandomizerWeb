// Pages/Admin/Quizzes/Answers/Index.cshtml.cs
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using webb_tst_site3.Data;
using webb_tst_site3.Models;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace webb_tst_site3.Pages.Admin.Quizzes.Questions.Answers
{
    public class IndexModel : PageModel
    {
        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        // ��������� ��������
        [FromQuery]
        public int QuizId { get; set; }

        [FromQuery]
        public int? QuestionId { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchText { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SortField { get; set; } = "QuestionOrder";

        [BindProperty(SupportsGet = true)]
        public string SortDirection { get; set; } = "asc";

        public PaginatedList<AnswerViewModel> Answers { get; set; }
        public Models.Quiz Quiz { get; set; }
        public Question Question { get; set; }

        public async Task<IActionResult> OnGetAsync(int quizId, int? questionId, int pageIndex = 1)
        {
            QuizId = quizId;
            QuestionId = questionId;

            // ��������� ���� �� ���� ������
            Quiz = await _context.Quizzes
                .Include(q => q.Questions)
                .FirstOrDefaultAsync(q => q.Id == quizId);

            if (Quiz == null)
            {
                return NotFound();
            }

            // ���� ������� questionId, ��������� � ������
            if (questionId.HasValue)
            {
                Question = await _context.Questions
                    .FirstOrDefaultAsync(q => q.Id == questionId.Value && q.QuizId == quizId);

                if (Question == null)
                {
                    return NotFound();
                }
            }

            // �������� ������ ��� �������
            IQueryable<Answer> answersQuery = _context.Answers
                .Include(a => a.Question)
                .Include(a => a.Result)
                .Where(a => a.Question.QuizId == quizId);

            // ������ �� �������, ���� �������
            if (questionId.HasValue)
            {
                answersQuery = answersQuery.Where(a => a.QuestionId == questionId.Value);
            }

            // ��������� �����, ���� ���� ��������� ������
            if (!string.IsNullOrEmpty(SearchText))
            {
                answersQuery = answersQuery.Where(a => a.Text.Contains(SearchText));
            }

            // ��������� ����������
            answersQuery = SortField switch
            {
                "QuestionOrder" => SortDirection == "asc"
                    ? answersQuery.OrderBy(a => a.Question.Order)
                    : answersQuery.OrderByDescending(a => a.Question.Order),
                "Text" => SortDirection == "asc"
                    ? answersQuery.OrderBy(a => a.Text)
                    : answersQuery.OrderByDescending(a => a.Text),
                "Score" => SortDirection == "asc"
                    ? answersQuery.OrderBy(a => a.Score)
                    : answersQuery.OrderByDescending(a => a.Score),
                "Result" => SortDirection == "asc"
                    ? answersQuery.OrderBy(a => a.Result.Name)
                    : answersQuery.OrderByDescending(a => a.Result.Name),
                _ => answersQuery.OrderBy(a => a.Text)
            };

            // ������� �������������� ������
            Answers = await PaginatedList<Answer>.CreateAsync(
                answersQuery.AsNoTracking(), pageIndex, pageSize);

            return Page();
        }

        public class AnswerViewModel
        {
            public int Id { get; set; }
            public string Text { get; set; }
            public int Score { get; set; }
            public string ResultName { get; set; }
            public int QuestionId { get; set; }
            public string QuestionText { get; set; }
            public int QuestionOrder { get; set; }
        }
    }

    public class PaginatedList<T> : List<T>
    {
        public int PageIndex { get; private set; }
        public int TotalPages { get; private set; }

        public PaginatedList(List<T> items, int count, int pageIndex, int pageSize)
        {
            PageIndex = pageIndex;
            TotalPages = (int)Math.Ceiling(count / (double)pageSize);
            this.AddRange(items);
        }

        public bool HasPreviousPage => PageIndex > 1;
        public bool HasNextPage => PageIndex < TotalPages;

        public static PaginatedList<T> Create(List<T> source, int pageIndex, int pageSize)
        {
            var count = source.Count;
            var items = source.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            return new PaginatedList<T>(items, count, pageIndex, pageSize);
        }
    }
}